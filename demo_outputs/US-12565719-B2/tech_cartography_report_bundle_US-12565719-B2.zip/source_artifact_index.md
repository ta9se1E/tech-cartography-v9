# Source Artifact Index

- evidence_map_synthesis: /Users/esakitakusei/Documents/python/practice/portfolio/2026_Hackathon/PatentScout_AI_v7/outputs/evidence_map_synthesis/US-12565719-B2/evidence_map_synthesis.md
- evidence_map_json: /Users/esakitakusei/Documents/python/practice/portfolio/2026_Hackathon/PatentScout_AI_v7/outputs/evidence_map_synthesis/US-12565719-B2/evidence_map_synthesis.json
- reproducibility_summary: /Users/esakitakusei/Documents/python/practice/portfolio/2026_Hackathon/PatentScout_AI_v7/outputs/reproducibility_smoke/reproducibility_summary.md
- web_signal_review: /Users/esakitakusei/Documents/python/practice/portfolio/2026_Hackathon/PatentScout_AI_v7/outputs/web_signals/tavily_pan_carbon_fiber/review_pack/web_signal_review_summary.md
- web_signal_links_summary: /Users/esakitakusei/Documents/python/practice/portfolio/2026_Hackathon/PatentScout_AI_v7/outputs/web_signal_links/US-12565719-B2/patent_paper_web_signal_summary.md
- web_signal_links_actions: /Users/esakitakusei/Documents/python/practice/portfolio/2026_Hackathon/PatentScout_AI_v7/outputs/web_signal_links/US-12565719-B2/next_verification_actions.md
- strategic_watch_brief: /Users/esakitakusei/Documents/python/practice/portfolio/2026_Hackathon/PatentScout_AI_v7/outputs/strategic_watch_briefs/US-12565719-B2/strategic_watch_brief.md
- strategic_watch_actions: /Users/esakitakusei/Documents/python/practice/portfolio/2026_Hackathon/PatentScout_AI_v7/outputs/strategic_watch_briefs/US-12565719-B2/strategic_watch_next_actions.md
- selected_papers: /Users/esakitakusei/Documents/python/practice/portfolio/2026_Hackathon/PatentScout_AI_v7/outputs/openalex_limited_execution/selected_evidence_papers.csv